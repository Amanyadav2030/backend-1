const UserModel = require('./user.model');
const statisticModel = require('./statistics.model');
const ContentModel = require('./content.model');
module.exports = {UserModel,statisticModel,ContentModel};