const ContentRouter = require('./content.routes');
const UserRouter = require('./user.routes');
const StatisticsRouter = require('./statistics.routes');
module.exports = {ContentRouter,UserRouter,StatisticsRouter};